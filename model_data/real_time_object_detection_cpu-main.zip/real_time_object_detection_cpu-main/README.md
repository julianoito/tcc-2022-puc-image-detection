# Realtime object detection on CPU with OpenCV

This repository is for the [video tutorial](https://youtu.be/hVavSe60M3g) on object detection using OpenCV  for the channel [TheCodingBug](https://www.youtube.com/c/TheCodingBug?sub_confirmation=1).
